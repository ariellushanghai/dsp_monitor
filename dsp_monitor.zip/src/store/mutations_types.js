import {mapValues} from 'lodash'

const types = mapValues({
  'SET_WORKFLOWS': null,
  'SET_SUMMARY': null,
  'ADD_WORKFLOW': null

});

export default {
  types: types
}
