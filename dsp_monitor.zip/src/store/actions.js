
import types from './mutations_types'
import API from '@/service/api'

export const addWorkflow = ({ commit }, workflow) => {
  commit(types.ADD_WORKFLOW, workflow);
};

export const fetchDataOfOverview = (context) => {
  API.getAll().then(response => {
    this.results = response.data
  }).catch(err => {
    console.error('fetchDataOfOverview() =>', err);
  });
  commit(types.ADD_WORKFLOW, workflow);
};
