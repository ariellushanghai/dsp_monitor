import Vue from 'vue';
import Vuex from 'vuex';
import createLogger from 'vuex/dist/logger'
import createPersistedState from 'vuex-persistedstate'
import types from './mutations_types'
import * as actions from './actions';

Vue.use(Vuex);

const state = {
  user: {},
  summary: [],
  workflows: []

};

const mutations = {
  [types.LOGIN]: (state, data) => {
    localStorage.token = data;
    state.token = data;
  }
};

export default new Vuex.Store({
  actions,
  mutations,
  state,
  plugins: [createLogger(),
            createPersistedState({storage: window.sessionStorage})]
});
