<template>
  <el-container class="overview">
    <el-main>
      <el-row :gutter="20">
        <el-col :span="4" v-for="(group, index) in list_of_group_completeness" :key="group.title">
          <ChartCompleteness :height="height"
                             :title="group.label"
                             :id="group.dom_id"
                             :dom_id="group.dom_id"
                             :value="group.completeness">
          </ChartCompleteness>
        </el-col>
      </el-row>
    </el-main>
  </el-container>
</template>

<script>
  import ChartCompleteness from '@/components/ChartCompleteness'
  import {mapState} from 'vuex'
  import API from '@/service/api'
  import _ from 'lodash'

  export default {
    name: 'OverView',
    metaInfo: {
      titleTemplate: '%s-概览'
    },
    data() {
      return {
        list_of_group_completeness: [],
        height: '400px'
      }
    },
    computed: mapState({
      workflows_count: state => state.workflows.length
    }),
    mounted() {
      console.log(this.$store.state.workflows);
      console.log(this.workflows_count);
      this.fetchData();
    },
    methods: {
      fetchData() {
        API.getAll().then(res => {
          this.list_of_group_completeness = this.convertData(res.summary);

          console.log('fetched: ', this.list_of_group_completeness);
        });

      },
      convertData(raw) {
        let result = _.cloneDeep(raw);
        result.forEach(function (v) {
          console.log(v);
          v.completeness = v.completeness.toFixed(1);
          v.dom_id = `chart_overall_${v.name}`
        });
        console.log('result: ', result);
        return result;
      }

    },
    components: {
      ChartCompleteness
    }
  }
</script>

<style scoped>
  .overview {
    background-color: antiquewhite;
    min-height: 100%;
    position: relative;
  }
</style>
