<template>
  <el-container class="workflows">
    <el-main class="workflows-main">
      <el-row type="flex" style="height: 100%;">
        <el-col :span="4"
                style="height: 100%;background-color: #333644;overflow-y: auto;">
          <el-row type="flex">
            <el-col :span="24" style="">
              <work-flow-left-menu :data="workflow_menu_data"></work-flow-left-menu>
            </el-col>
          </el-row>
        </el-col>


        <el-col :span="20" style="height: 100%;position: relative;overflow: hidden;">
          <el-main style="padding: 0;height: 100%;width: 100%;position: relative;">
            <el-row class="chart-tabs-container">
              <el-tabs class="chart-tabs" type="border-card" v-model="active_workflow_layer"
                       @tab-click="handleLayerTabClick">
                <el-tab-pane class="chart-tabs-pane" v-for="tab in selected_workflow_layers" :name="tab" :label="tab"
                             :key="tab">
                  <ChartWorkflow :dom_id="chart_workflow_DOM_ID"
                                 :data="current_workflow_data"></ChartWorkflow>
                  <!--<el-row type="flex" class="chart-container">-->
                  <!--<ChartWorkflow :dom_id="chart_workflow_DOM_ID" :data="current_workflow_data"></ChartWorkflow>-->
                  <!--</el-row>-->
                </el-tab-pane>
              </el-tabs>
              <!--<el-tabs type="card">-->
              <!--<el-tab-pane label="用户管理" name="first">用户管理</el-tab-pane>-->
              <!--<el-tab-pane label="配置管理" name="second">配置管理</el-tab-pane>-->
              <!--<el-tab-pane label="角色管理" name="third">角色管理</el-tab-pane>-->
              <!--<el-tab-pane label="定时任务补偿" name="fourth">定时任务补偿</el-tab-pane>-->
              <!--</el-tabs>-->

            </el-row>

          </el-main>
        </el-col>

      </el-row>
    </el-main>
  </el-container>
</template>

<script>
  import ChartWorkflow from '@/components/ChartWorkflow'
  import WorkFlowLeftMenu from '@/components/WorkFlowLeftMenu'
  import {mapState} from 'vuex'
  import API from '@/service/api'
  import _ from 'lodash'

  export default {
    name: 'Workflows',
    metaInfo: {
      titleTemplate: '%s-Workflows'
    },
    data() {
      return {
        workflows: [],
        workflow_menu_data: [],
        selected_workflow: {
          layers: ['BASE', 'RAW', 'MID']
        },
        defaultProps: {
          children: 'children',
          label: 'label'
        },
        active_workflow_layer: 'BASE',
        chart_workflow_DOM_ID: 'chart_workflow',
        current_workflow_data: {}
      }
    },
    computed: {
      selected_workflow_layers: function () {
        console.log('this.selected_workflow.layers:', this.selected_workflow.layers);
        // return _.keys(this.selected_workflow);
        return this.selected_workflow.layers;
      }
    },
    mounted() {
      // console.log(this.$store.state.workflows);
      // console.log(this.workflows_count);
      this.fetchData('all_workflows');
    },
    beforeRouteEnter(to, from, next) {
      console.log('beforeRouteEnter(', to, from, next, ')');
      console.log(to.params);
      console.log(to.params.rootJobId);
      next();
    },
    beforeRouteUpdate(to, from, next) {
      console.log('beforeRouteUpdate(', to, from, next, ')');
      console.log(to.params.rootJobId);
      this.fetchData('layers', to.params.rootJobId);
      next();
    },
    methods: {
      fetchData(what, param) {
        let self = this;
        switch (what) {
          case 'all_workflows':
            API.getAll().then(res => {
              self.workflows = res.workflows;
              self.workflow_menu_data = self.ConstructureMenu(res.summary);
              // console.log('fetched: ', self.workflows);
            });
            break;
          case 'layers':
            API.getLayers().then(res => {
              self.selected_workflow.layers = res;
              console.log(_.keys(res));
            });
            break;
          default:
            console.log(`fetchData(${arguments})`);
        }


      },
      ConstructureMenu(raw) {
        console.log(`ConstructureMenu(`, raw, `)`);
        let self = this;
        let menu = [];
        if (raw === []) {
          return menu;
        }

        raw.forEach(function (group) {
          menu.push({
            name: group.name,
            label: `${group.label} ` + group.completeness.toFixed(1) + `%`,
            children: []
          });
        });

        // console.log('self.$route.name: ', self.$route.name);
        self.workflows.forEach(function (each_workflow) {
          _.find(menu, {'name': each_workflow.category}).children.push({
            label: `${each_workflow.name}`,
            rootJobId: each_workflow.rootJobId,
            route: `${each_workflow.rootJobId}`
          });
        });

        console.log('menu: ', menu);
        return menu;
      },
      handleLayerTabClick() {
        console.log('handleLayerTabClick()');
      }
    },
    components: {
      ChartWorkflow,
      WorkFlowLeftMenu
    }
  }
</script>

<style scoped>
  .workflows {
    background-color: antiquewhite;
    width: 100%;
    height: 100%;
    position: relative;
  }

  .workflows .workflows-main {
    padding: 0;
    width: 100%;
    height: 100%;
    position: relative;
    overflow: hidden;
  }

  .chart-tabs-container {
    /*height: 100px;*/
    height: 100%;
  }

  .chart-tabs {
    height: 100%;
  }

  /*.chart-tabs-pane {*/
  /*height: calc(100% - 40px);*/
  /*}*/

  /*.chart-container {*/
  /*!*height: calc(100% - 100px);*!*/
  /*height: 100%;*/
  /*!*position: absolute;*!*/
  /*position: relative;*/
  /*!*top: 100px;*!*/
  /*!*left: 0;*!*/
  /*!*right: 0;*!*/
  /*!*bottom: 0;*!*/
  /*width: 100%;*/
  /*}*/

  .left-menu {
    border-right: 1px solid #333644;
  }
</style>
