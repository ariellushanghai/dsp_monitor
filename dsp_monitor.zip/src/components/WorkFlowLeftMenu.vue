<template>
  <el-menu
    router
    class="left-menu"
    @select="handleSelectMenu"
    @open="handleOpenMenu"
    @close="handleCloseMenu"
    background-color="#333644"
    text-color="#fff"
    active-text-color="#EA5505">

    <el-submenu v-for="(item, idx) in data" :index="String(idx)" :key="item.label">
      <template slot="title">
        <i class="el-icon-tickets"></i>
        <span>{{item.label}}</span>
      </template>

      <el-menu-item v-for="(wf, idx) in item.children" :index="String(wf.rootJobId)" :key="wf.rootJobId"
                    :title="wf.label" :route="wf.route">
        <span slot="title">{{wf.label}}</span>
      </el-menu-item>
    </el-submenu>
  </el-menu>
</template>

<script>
  export default {
    name: "WorkFlowLeftMenu",
    props: ['data'],
    data() {
      return {};
    },
    mounted() {
      console.log(this.$route)
    },
    beforeRouteUpdate (to, from, next) {
      console.log('beforeRouteEnter()')
      // 在当前路由改变，但是该组件被复用时调用
      // 举例来说，对于一个带有动态参数的路径 /foo/:id，在 /foo/1 和 /foo/2 之间跳转的时候，
      // 由于会渲染同样的 Foo 组件，因此组件实例会被复用。而这个钩子就会在这个情况下被调用。
      // 可以访问组件实例 `this`
    },
    methods: {
      handleSelectMenu(key, keyPath) {
        console.log('handleSelectMenu(', key, keyPath, ')');
      },
      handleOpenMenu(key, keyPath) {
        console.log('handleOpenMenu(', key, keyPath, ')');
      },
      handleCloseMenu(key, keyPath) {
        console.log('handleCloseMenu(', key, keyPath, ')');
      }
    }
  }
</script>

<style scoped>
  .left-menu .el-submenu .el-menu-item {
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .left-menu .el-menu-item {
    font-size: 12px;
  }
</style>
